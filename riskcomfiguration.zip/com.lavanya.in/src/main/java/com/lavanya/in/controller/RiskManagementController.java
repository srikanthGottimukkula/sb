package com.lavanya.in.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lavanya.in.Dto.RiskCheckRequest;
import com.lavanya.in.Dto.RiskCheckResponse;
import com.lavanya.in.service.RiskManagementService;

@RestController
@RequestMapping("/api/risk")
public class RiskManagementController {

	@Autowired
	private RiskManagementService riskManagementService;

	@PostMapping("/check")
	public RiskCheckResponse checkRisk(@RequestBody RiskCheckRequest request) {
		return riskManagementService.checkRisk(request);
	}
}