package com.lavanya.in.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lavanya.in.Dto.RiskCheckRequest;
import com.lavanya.in.Dto.RiskCheckResponse;
import com.lavanya.in.model.RiskConfiguration;
import com.lavanya.in.repository.RiskConfigurationRepository;

@Service
public class RiskManagementService {

	@Autowired
	private RiskConfigurationRepository riskConfigurationRepository;

	public RiskCheckResponse checkRisk(RiskCheckRequest request) {
		RiskConfiguration config = riskConfigurationRepository.findBySymbol(request.getSymbol());

		if (config == null) {
			throw new RuntimeException("Risk configuration not found for symbol: " + request.getSymbol());
		}

		boolean allowed = request.getLeverage() <= config.getMaxLeverage()
				&& request.getVolume() <= config.getMaxVolume()
				&& request.getAccountBalance() >= config.getMinAccountBalance();

		return new RiskCheckResponse(allowed, config.getMaxVolume());
	}
}
