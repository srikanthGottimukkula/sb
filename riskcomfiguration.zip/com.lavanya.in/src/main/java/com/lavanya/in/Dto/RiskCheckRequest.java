package com.lavanya.in.Dto;

public class RiskCheckRequest {
	private String symbol;
	private double volume;
	private double leverage;
	private double accountBalance;

	public RiskCheckRequest(String symbol, double volume, double leverage, double accountBalance) {
		super();
		this.symbol = symbol;
		this.volume = volume;
		this.leverage = leverage;
		this.accountBalance = accountBalance;
	}

	public RiskCheckRequest() {
		super();
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public double getVolume() {
		return volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

	public double getLeverage() {
		return leverage;
	}

	public void setLeverage(double leverage) {
		this.leverage = leverage;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

}
