package com.lavanya.in.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "RISK_CONFIGURATION")
public class RiskConfiguration {
	@Id
	private String symbol;
	private double maxLeverage;
	private double maxVolume;
	private double minAccountBalance;

	public RiskConfiguration() {
		super();
	}

	public RiskConfiguration(String symbol, double maxLeverage, double maxVolume, double minAccountBalance) {
		super();
		this.symbol = symbol;
		this.maxLeverage = maxLeverage;
		this.maxVolume = maxVolume;
		this.minAccountBalance = minAccountBalance;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public double getMaxLeverage() {
		return maxLeverage;
	}

	public void setMaxLeverage(double maxLeverage) {
		this.maxLeverage = maxLeverage;
	}

	public double getMaxVolume() {
		return maxVolume;
	}

	public void setMaxVolume(double maxVolume) {
		this.maxVolume = maxVolume;
	}

	public double getMinAccountBalance() {
		return minAccountBalance;
	}

	public void setMinAccountBalance(double minAccountBalance) {
		this.minAccountBalance = minAccountBalance;
	}

	@Override
	public String toString() {
		return "RiskConfiguration [symbol=" + symbol + ", maxLeverage=" + maxLeverage + ", maxVolume=" + maxVolume
				+ ", minAccountBalance=" + minAccountBalance + "]";
	}

}