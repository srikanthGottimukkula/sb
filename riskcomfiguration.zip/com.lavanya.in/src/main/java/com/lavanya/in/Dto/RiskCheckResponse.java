package com.lavanya.in.Dto;

public class RiskCheckResponse {
	private boolean allowed;
	private double maxVolume;

	public RiskCheckResponse(boolean allowed, double maxVolume) {
		this.allowed = allowed;
		this.maxVolume = maxVolume;
	}

	public RiskCheckResponse() {
		super();
	}

	public boolean isAllowed() {
		return allowed;
	}

	public void setAllowed(boolean allowed) {
		this.allowed = allowed;
	}

	public double getMaxVolume() {
		return maxVolume;
	}

	public void setMaxVolume(double maxVolume) {
		this.maxVolume = maxVolume;
	}

}